<?php

echo view('layout/v_header_admin');
echo view('layout/v_nav_admin');
echo view('layout/v_content');
echo view('layout/v_footer_admin');
