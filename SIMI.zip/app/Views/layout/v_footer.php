<!-- ======= Footer ======= -->
<footer id="" class="footer">
    <div class="copyright">
        &copy; Copyright <strong><span>SIMI</span></strong>. All Rights Reserved
    </div>
</footer>

<a href="#" class="back-to-top d-flex align-items-center justify-content-center bg-green"><i class="bi bi-arrow-up-short " style="color: white !important;"></i></a>

<!-- Vendorr JS Files -->
<script src="<?= base_url('NiceAdmin') ?>/assets/vendorr/purecounter/purecounter_vanilla.js"></script>
<script src="<?= base_url('NiceAdmin') ?>/assets/vendorr/bootstrap/js/bootstrap.bundle.min.js"></script>
<script src="<?= base_url('NiceAdmin') ?>/assets/vendorr/glightbox/js/glightbox.min.js"></script>
<script src="<?= base_url('NiceAdmin') ?>/assets/vendorr/isotope-layout/isotope.pkgd.min.js"></script>
<script src="<?= base_url('NiceAdmin') ?>/assets/vendorr/swiper/swiper-bundle.min.js"></script>
<script src="<?= base_url('NiceAdmin') ?>/assets/vendorr/php-email-form/validate.js"></script>

<!-- Template Main JS File -->
<script src="<?= base_url('NiceAdmin') ?>/assets/js/main.js"></script>
<!-- jquery -->
<script src="<?= base_url() ?>/assets/js/jquery-3.6.4.min.js"></script>


<!-- <script>
    $('.nav-link').on('click', function() {
        $(this).addClass('active');
        
    })
</script> -->
<script>
    AOS.init();
</script>
</body>

</html>